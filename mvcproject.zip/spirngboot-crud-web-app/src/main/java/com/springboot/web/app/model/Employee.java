package com.springboot.web.app.model;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotBlank;

@Entity
@Table(name = "employees")
public class Employee {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;

    @NotBlank(message = "Employee First Name not be empty")
    @Column
    private String firstName;

    @NotBlank(message = "Employee Last Name not be empty")
    @Column
    private String lastName;

    @NotBlank(message = "Employee Email not be empty")
    @Column
    private String email;
    
    @NotBlank(message = "Employee Skill not be empty")
    @Column
    private String skill;
    
    @Column
    private String projectassigned;
    
    @Column
    private String category;
    
    
    public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public String getProjectassigned() {
		return projectassigned;
	}
	public void setProjectassigned(String projectassigned) {
		this.projectassigned = projectassigned;
	}
	public String getSkill() {
		return skill;
	}
	public void setSkill(String skill) {
		this.skill = skill;
	}
	public long getId() {
        return id;
    }
    public void setId(long id) {
        this.id = id;
    }
    public String getFirstName() {
        return firstName;
    }
    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }
    public String getLastName() {
        return lastName;
    }
    public void setLastName(String lastName) {
        this.lastName = lastName;
    }
    public String getEmail() {
        return email;
    }
    public void setEmail(String email) {
        this.email = email;
    }
}