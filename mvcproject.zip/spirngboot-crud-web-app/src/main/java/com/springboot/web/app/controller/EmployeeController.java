package com.springboot.web.app.controller;

import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import com.springboot.web.app.model.Employee;
import com.springboot.web.app.service.EmployeeService;

@Controller
public class EmployeeController {

	@Autowired
	private EmployeeService employeeService;

	// display list of employees
	@GetMapping("/view")
	public String viewHomePage(Model model) {
		List<Employee> list = employeeService.getAllEmployees();
		List<Employee> list1 = new ArrayList<>();
		List<Employee> list2 = new ArrayList<>();
		for (Employee employee : list) {
			System.out.println(employee.getProjectassigned());
			if (employee.getCategory().equalsIgnoreCase("Yes")) {
				list1.add(employee);

			} else {
				list2.add(employee);

			}
		}
		model.addAttribute("listEmployees", list1);
		model.addAttribute("newList", list2);
		return "index";
	}

	@GetMapping("/")
	public String showNewEmployeeForm(Model model) {
		// create model attribute to bind form data
		Employee employee = new Employee();
		model.addAttribute("employee", employee);

		return "new_employee";
	}

	@PostMapping("/saveEmployee")
	public String saveEmployee(@Valid @ModelAttribute("employee") Employee employee, BindingResult result,
			Model model) {
		// save employee to database
		if (result.hasErrors()) {
			return "new_employee";
		}
		System.out.println(employee.getProjectassigned());

		if (employee.getCategory().equalsIgnoreCase("No")) {
			employee.setProjectassigned(null);
		}
		employeeService.saveEmployee(employee);
		return "redirect:/view";
	}

	@GetMapping("/showFormForUpdate/{id}")
	public String showFormForUpdate(@PathVariable(value = "id") long id, Model model) {

		// get employee from the service
		Employee employee = employeeService.getEmployeeById(id);

		// set employee as a model attribute to pre-populate the form
		model.addAttribute("employee", employee);
		return "update_employee";
	}

	@GetMapping("/deleteEmployee/{id}")
	public String deleteEmployee(@PathVariable(value = "id") long id) {

		// call delete employee method
		this.employeeService.deleteEmployeeById(id);
		return "redirect:/view";
	}
}